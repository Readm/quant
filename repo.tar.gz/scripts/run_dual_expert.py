"""
run_dual_expert.py — 双专家量化系统入口（纯Python版）

用法：
  python3 scripts/run_dual_expert.py --rounds 2 --symbols 000001.SZ BTCUSDT

无外部依赖，直接运行。
"""

import sys, argparse, json, math, random, os
from pathlib import Path
from datetime import datetime

# ── 关键：加入 quant/ 父目录使 experts 模块可导入 ─────
sys.path.insert(0, str(Path(__file__).parent.parent))

# ─────────────────────────────────────────────
#  数据生成（逼真模拟）
# ─────────────────────────────────────────────

def generate_realistic_data(symbol: str, n_days: int = 500, seed: int = 42) -> tuple:
    """
    生成有趋势+震荡结构的模拟价格序列。
    返回: (symbol_name, closes, highs, lows)
    """
    random.seed(seed + hash(symbol) % 1000)
    dates = list(range(n_days))

    # 分段构造趋势
    returns = [random.gauss(0.0003, 0.018) for _ in range(n_days)]

    # 加入趋势段落
    phases = [(0, 150, 0.0008),   # 牛市
               (150, 280, -0.0005), # 熊市
               (280, 400, 0.0010),  # 牛市
               (400, n_days, -0.0003)] # 震荡
    for s, e, drift in phases:
        for i in range(s, min(e, n_days)):
            returns[i] += drift

    # 加入事件冲击
    for idx in [50, 120, 200, 310, 380, 450]:
        if idx < n_days:
            returns[idx] += random.choice([-1, 1]) * random.uniform(0.025, 0.06)

    # 积分价格
    base_price = 100.0 if "SZ" in symbol or "SH" in symbol else 50000.0
    closes = [base_price]
    for r in returns[1:]:
        closes.append(closes[-1] * (1 + r))

    closes = closes[:n_days]

    # 生成高低点
    highs, lows = [], []
    for i, c in enumerate(closes):
        ext = c * random.uniform(0, 0.008)
        highs.append(c + ext)
        lows.append(c - ext)

    return symbol, closes, highs, lows


# ─────────────────────────────────────────────
#  专家系统入口
# ─────────────────────────────────────────────

def load_symbols(symbols: list, n_days: int = 500) -> list:
    """加载所有标的，返回 list of (name, closes, highs, lows)"""
    data = []
    for sym in symbols:
        name, closes, highs, lows = generate_realistic_data(sym, n_days=n_days)
        data.append((name, closes, highs, lows))
        print(f"  ✅ {sym}：{n_days} 个交易日，"
              f"区间 {min(closes):.1f} ~ {max(closes):.1f}")
    return data


def print_final_summary(report: dict):
    print("\n" + "🏆" * 32)
    print("  双专家迭代 · 最终报告")
    print("🏆" * 32)

    print(f"\n📅 生成时间：{report['generated_at']}")
    print(f"🔄 总轮次  ：{report['total_rounds']}")
    print(f"📊 标的池  ：{report['symbols']}")

    print(f"\n{'─' * 60}")
    print("  轮次 | 候选 | Top1策略              | 分  | 夏普  | 回撤  | 胜率")
    print(f"{'─' * 60}")
    for rnd in report["rounds_log"]:
        t = rnd["top3"][0] if rnd["top3"] else {}
        name = t.get("name", "N/A")[:18]
        print(f"  第{rnd['round']}轮  |   6   | {name:20s} | "
              f"{t.get('score', 0):4.1f} | {t.get('sharpe', 0):5.3f} | "
              f"{t.get('drawdown', 0):5.1f}% | {t.get('winrate', 0):5.1f}%")
    print(f"{'─' * 60}")

    print(f"\n🏆 全局最优策略 Top {len(report['final_top_strategies'])}：")
    for s in report["final_top_strategies"]:
        decision_icon = "✅" if s["decision"] == "ACCEPT" else "⚠️"
        print(f"\n  #{s['rank']} {decision_icon} {s['name']}（{','.join(s['tags'])}）")
        print(f"     综合分: {s['composite_score']}/100")
        print(f"     总收益: {s['total_return']:+.1f}%  |  年化: {s['annualized_return']:+.1f}%")
        print(f"     夏普: {s['sharpe_ratio']:.3f}  |  卡曼: {s['calmar_ratio']:.3f}  |  索提诺: {s['sortino_ratio']:.3f}")
        print(f"     回撤: {s['max_drawdown_pct']:.1f}%  |  胜率: {s['win_rate']:.1f}%  |  盈亏比: {s['profit_factor']:.2f}")
        print(f"     交易次数: {s['total_trades']}  |  平均持仓: {s['avg_holding_days']:.0f}天")
        print(f"     最优参数: {s['params']}")
        print(f"     评估建议: {s['decision']} — {s.get('feedback', '')[:80]}")

    ca = report.get("convergence_analysis", {})
    if ca:
        print(f"\n📈 收敛分析：")
        print(f"  第1轮 Top1: {ca.get('round1_top_score', 0):.1f} 分  →  "
              f"第{report['total_rounds']}轮 Top1: {ca.get('final_top_score', 0):.1f} 分  "
              f"（{ca.get('direction', '')} {abs(ca.get('delta', 0)):.1f}）")
        print(f"  → {ca.get('interpretation', '')}")

    suggestions = report.get("investment_suggestion", {}).get("suggestions", [])
    if suggestions:
        print(f"\n💡 投资建议：")
        for sg in suggestions:
            print(f"  【{sg.get('risk_level')}】")
            print(f"    策略: {sg.get('strategy')}  参数: {sg.get('params')}")
            print(f"    预期收益: {sg.get('expected_return')}  最大风险: {sg.get('max_loss_risk')}")
            print(f"    操作: {sg.get('action')}")

    print("\n" + "🏆" * 32)


def main():
    parser = argparse.ArgumentParser(description="双专家量化策略迭代系统")
    parser.add_argument("--rounds",  type=int, default=2,    help="迭代轮次（默认2）")
    parser.add_argument("--symbols", nargs="+",
                        default=["000001.SZ", "BTCUSDT", "ETHUSDT"],
                        help="标的列表")
    parser.add_argument("--days",    type=int, default=500,  help="历史数据天数")
    parser.add_argument("--top-n",  type=int, default=3,    help="保留Top策略数")
    parser.add_argument("--seed",    type=int, default=2026,  help="随机种子（可复现）")
    parser.add_argument("--output",  default=None,           help="报告保存路径")
    args = parser.parse_args()

    random.seed(args.seed)

    print("\n🔵" * 32)
    print("  双专家量化策略迭代系统 v2.0")
    print("  Expert1: 策略生成 + 回测 + 参数调优")
    print("  Expert2: 多维评估 + 筛选 + 反馈")
    print("🔵" * 32)
    print(f"\n📥 生成模拟市场数据（随机种子={args.seed}）...")

    symbols_data = load_symbols(args.symbols, n_days=args.days)

    print(f"\n🚀 启动 {args.rounds} 轮双专家迭代...")

    import sys as _sys2
    _sys2.path.insert(0, str(Path(__file__).parent.parent))
    from experts.coordinator import Coordinator
    coord = Coordinator(symbols_data, max_rounds=args.rounds, top_n=args.top_n)
    final_report = coord.run()

    # 保存
    out_path = args.output or str(
        Path(__file__).parent.parent / "results" /
        f"dual_expert_{datetime.now().strftime('%Y%m%d_%H%M')}.json"
    )
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(final_report, f, ensure_ascii=False, indent=2)
    print(f"\n💾 报告已保存：{out_path}")

    print_final_summary(final_report)
    print("✅ 完成！")


if __name__ == "__main__":
    # 确保 quant/ 加入路径
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).parent.parent))
    main()
