"""scripts/run_live.py - 实盘入口"""
import sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from engine.execution.scheduler import Scheduler
from engine.execution.broker import TigerBroker, BinanceBroker
from engine.strategies.day_strategy import DayStrategy
from engine.portfolio.portfolio_manager import PortfolioManager
from engine.risk.risk_engine import RiskEngine
from config.settings import INITIAL_CASH, RISK, STOCK_BROKER, CRYPTO_API_KEY, CRYPTO_SECRET
from config.markets import INTRADAY_WINDOWS

def daily_task(pm, risk, brokers):
    print("[实盘] 日线任务")
    # TODO: 数据更新 + 信号生成 + 发单

def intraday_task(pm, risk, brokers, symbol):
    print(f"[实盘] 日内 {symbol}")
    # TODO: 日内择时信号 + 发单

def main():
    pm   = PortfolioManager(INITIAL_CASH, RISK["max_position_pct"])
    risk = RiskEngine(pm, {})
    brokers = {}
    if STOCK_BROKER.get("account"):
        try:
            brokers["stocks"] = TigerBroker(STOCK_BROKER["account"],STOCK_BROKER["token"]).connect()
        except Exception as e:
            print(f"老虎证券连接失败: {e}")
    if CRYPTO_API_KEY:
        try:
            brokers["crypto"] = BinanceBroker(CRYPTO_API_KEY, CRYPTO_SECRET).connect()
        except Exception as e:
            print(f"Binance连接失败: {e}")
    sched = Scheduler(risk, brokers)
    sched.schedule_daily(lambda: daily_task(pm, risk, brokers), hour=16, minute=0)
    for sym in ["BTCUSDT","ETHUSDT"]:
        sched.schedule_intraday(lambda s: intraday_task(pm,risk,brokers,s), sym, "crypto")
    sched.start()
    while True: time.sleep(3600)

if __name__=="__main__": main()
