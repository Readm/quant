"""engine/execution/broker.py - 券商接口抽象"""
import sys; from pathlib import Path; from abc import ABC, abstractmethod
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

class Broker(ABC):
    @abstractmethod
    def connect(self): pass
    @abstractmethod
    def get_positions(self): pass
    @abstractmethod
    def send_order(self, order): pass
    @abstractmethod
    def get_realtime_price(self, symbol): pass

class TigerBroker(Broker):
    """老虎证券 OpenAPI（A股/港股/美股）"""
    def __init__(self, account, token):
        self.account = account; self.token = token; self.base = "https://openapi.tigerbrokers.com"

    def connect(self):
        import requests
        r = requests.post(f"{self.base}/user/auth/token", json={"grant_type":"api_key","key":self.token}, timeout=10)
        r.raise_for_status()
        self.token = r.json()["data"]["access_token"]
        return self

    def get_positions(self):
        import requests
        r = requests.get(f"{self.base}/fundaccount/position", headers={"Authorization": f"Bearer {self.token}"}, timeout=10)
        return r.json().get("data", {})

    def send_order(self, order):
        import requests
        payload = {"account":self.account,"symbol":order["symbol"],
                   "action":order["action"].upper(),"type":"STOCK",
                   "quantity":order["shares"],"priceType":2}
        r = requests.post(f"{self.base}/order/new", headers={"Authorization":f"Bearer {self.token}"}, json=payload, timeout=10)
        return r.json()

    def get_realtime_price(self, symbol):
        import requests
        r = requests.get(f"{self.base}/quote/real", params={"symbols":symbol},
                       headers={"Authorization":f"Bearer {self.token}"}, timeout=10)
        data = r.json().get("data",{}); return data.get(symbol,{}).get("last",0)

class BinanceBroker(Broker):
    """Binance 现货（加密货币）"""
    def __init__(self, api_key="", secret=""):
        self.api_key=api_key; self.secret=secret

    def connect(self):
        import ccxt; self.ex=ccxt.binance({"enableRateLimit":True,
                                           "apiKey":self.api_key,"secret":self.secret}); return self

    def get_positions(self):
        return self.ex.fetch_balance()

    def send_order(self, order):
        pair = f"{order['symbol'][:3]}/{order['symbol'][3:]}"
        return self.ex.create_order(pair,"market",order["action"].lower(),order["shares"])

    def get_realtime_price(self, symbol):
        pair = f"{symbol[:3]}/{symbol[3:]}"
        return self.ex.fetch_ticker(pair)["last"]
