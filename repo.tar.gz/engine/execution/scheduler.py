"""engine/execution/scheduler.py"""
import sched, threading, time, datetime as dt
from config.markets import INTRADAY_WINDOWS

class Scheduler:
    def __init__(self, engine, brokers):
        self.engine=engine; self.brokers=brokers
        self.sched=sched.scheduler(time.time,time.sleep); self._t=None

    def schedule_daily(self, fn, hour=16, minute=0):
        def wrap():
            print(f"[Scheduler] 日线 {dt.datetime.now()}")
            try: fn()
            except Exception as e: print(f"异常: {e}")
            self.schedule_daily(fn, hour, minute)
        self._add(wrap, hour, minute)

    def schedule_intraday(self, fn, symbol, market):
        for hw in INTRADAY_WINDOWS.get(market,[]):
            h,m=map(int,hw.split(":")); self._add(lambda s=symbol: fn(s), h, m)

    def _add(self, fn, hour, minute):
        now=dt.datetime.now(); nd=now.replace(hour=hour,minute=minute,second=0,microsecond=0)
        if nd<=now: nd+=dt.timedelta(days=1)
        self.sched.enter((nd-now).total_seconds(),0,fn)

    def start(self):
        self._t=threading.Thread(target=self.sched.run,daemon=True); self._t.start()
        print("[Scheduler] 启动")
    def stop(self): self.sched.cancel()
