"""engine/portfolio/portfolio_manager.py - 组合管理器"""
class PortfolioManager:
    def __init__(self, initial_cash, max_position_pct=0.20):
        self.initial_cash      = initial_cash
        self.max_position_pct  = max_position_pct
        self.current_cash     = initial_cash
        self.positions = {}  # {symbol: {"shares":int,"avg_cost":float,"market":str}}

    def total_equity(self, prices):
        pos_val = sum(shares * prices.get(s, 0) for s, _ in self.positions.items())
        return self.current_cash + pos_val

    def compute_order(self, symbol, signal, price, market="stocks"):
        action = signal.get("action", "hold")
        if action == "hold": return None
        equity  = self.total_equity({symbol: price})
        max_pct = self.max_position_pct * signal.get("confidence", 0.5)
        if action == "buy":
            shares = int((equity * max_pct) / price)
            if shares <= 0: return None
            return {"action":"buy","symbol":symbol,"shares":shares,"price":price,"market":market}
        elif action == "sell" and symbol in self.positions:
            return {"action":"sell","symbol":symbol,"shares":self.positions[symbol]["shares"],
                    "price":price,"market":market}
        return None

    def apply_filled_order(self, order, fill_price):
        if order is None: return
        sym    = order["symbol"]
        shares = order["shares"]
        action = order["action"]
        if action == "buy":
            cost  = shares * fill_price
            self.current_cash -= cost
            if sym in self.positions:
                old  = self.positions[sym]
                total = old["shares"] + shares
                self.positions[sym] = {"shares": total,
                    "avg_cost": (old["avg_cost"]*old["shares"] + fill_price*shares)/total,
                    "market": order["market"]}
            else:
                self.positions[sym] = {"shares": shares, "avg_cost": fill_price, "market": order["market"]}
        elif action == "sell" and sym in self.positions:
            self.current_cash += shares * fill_price
            self.positions[sym]["shares"] -= shares
            if self.positions[sym]["shares"] <= 0: del self.positions[sym]
