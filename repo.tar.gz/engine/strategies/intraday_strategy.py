"""engine/strategies/intraday_strategy.py - 日内择时骨架"""
from .base_strategy import BaseStrategy

class IntradayStrategy(BaseStrategy):
    """
    日内择时策略（不隔夜持仓，收盘前平仓）
    算法待填
    """

    def __init__(self):
        super().__init__("IntradayStrategy", market="stocks")

    def on_bar(self, bar):
        """逐根K线处理"""
        closes = [bar["close"]]
        if len(closes) < 20:
            return {"action": "hold", "size": 0.0}
        # ── 日内算法区域（待填）────────────────────────────
        ma = sum(closes[-20:]) / 20
        cur = closes[-1]
        # ──────────────────────────────────────────────
        if cur < ma * 0.98:
            return {"action": "buy",  "reason": "低于均值2%", "size": 1.0}
        if cur > ma * 1.02:
            return {"action": "sell", "reason": "高于均值2%", "size": 1.0}
        return {"action": "hold", "size": 0.0}

    def should_close_at_close(self, symbol):
        """日内策略收盘必须平仓"""
        return True
