"""engine/strategies/day_strategy.py - 日线策略骨架（算法待填）"""
from .base_strategy import BaseStrategy

class DayStrategy(BaseStrategy):
    """
    日线级趋势跟踪策略
    算法层待填入具体信号逻辑
    """

    def __init__(self):
        super().__init__("DayStrategy", market="stocks")
        self.price_history = {}

    def on_daily_signal(self, symbol, df_daily):
        """返回 {"action": "buy"|"sell"|"hold", "reason": str, "confidence": float}"""
        if len(df_daily) < 60:
            return {"action": "hold", "reason": "数据不足", "confidence": 0.0}

        closes = df_daily["close"].values
        # ── 算法区域（待填入具体策略逻辑）────────────────────
        # 示例骨架：双均线
        fast_ma = sum(closes[-20:]) / 20
        slow_ma = sum(closes[-60:]) / 60
        # ─────────────────────────────────────────────────
        if fast_ma > slow_ma:
            return {"action": "buy",  "reason": "均线多头", "confidence": 0.6}
        elif fast_ma < slow_ma:
            return {"action": "sell", "reason": "均线空头", "confidence": 0.6}
        return {"action": "hold", "reason": "无信号", "confidence": 0.0}

    def on_bar(self, bar):
        sym = bar["symbol"]
        if sym not in self.price_history:
            self.price_history[sym] = []
        self.price_history[sym].append(bar["close"])
        return {"action": "hold", "size": 0.0}

    def on_intraday_signal(self, symbol, df_minute):
        if len(df_minute) < 30:
            return {"action": "hold", "reason": "数据不足", "confidence": 0.0}
        return {"action": "hold", "reason": "未定义", "confidence": 0.0}
