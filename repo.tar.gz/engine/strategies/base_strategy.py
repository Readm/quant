"""engine/strategies/base_strategy.py - 策略基类"""
from abc import ABC, abstractmethod

class BaseStrategy(ABC):
    """所有策略的基类"""

    def __init__(self, name, market="stocks"):
        self.name   = name
        self.market = market
        self.positions = {}
        self.signals   = {}
        self.params    = {}

    def set_params(self, **kwargs):
        self.params.update(kwargs)

    @abstractmethod
    def on_bar(self, bar: dict):
        raise NotImplementedError

    def on_daily_signal(self, symbol, df_daily):
        """日线信号回调（每标的每日收盘后调用一次）"""
        return {"action": "hold", "reason": "not implemented", "confidence": 0.0}

    def on_intraday_signal(self, symbol, df_minute):
        """日内信号回调"""
        return {"action": "hold", "reason": "not implemented", "confidence": 0.0}

    def reset(self):
        self.positions.clear(); self.signals.clear()
