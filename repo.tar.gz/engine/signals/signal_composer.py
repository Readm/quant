"""engine/signals/signal_composer.py - 多信号合成器"""
class SignalComposer:
    def __init__(self, strategies, weights=None):
        self.strategies = strategies
        self.weights    = weights or {s.name: 1.0 for s in strategies}

    def get_composite_signal(self, symbol, df_daily, df_intraday=None):
        buy_s, sell_s, reasons = 0.0, 0.0, []
        for strat in self.strategies:
            sig    = strat.on_daily_signal(symbol, df_daily)
            action = sig.get("action", "hold")
            conf   = sig.get("confidence", 0.5)
            score  = conf * self.weights.get(strat.name, 1.0)
            if action == "buy":   buy_s  += score
            elif action == "sell": sell_s += score
            reasons.append(f"{strat.name}:{action}({conf:.2f})")
        net = buy_s - sell_s
        if net > 0.3:  return {"action":"buy",  "net":net, "reasons":reasons}
        if net < -0.3: return {"action":"sell", "net":net, "reasons":reasons}
        return {"action":"hold", "net":net, "reasons":reasons}

    def reset_all(self):
        for s in self.strategies: s.reset()
