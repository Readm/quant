"""engine/risk/risk_engine.py - 风控引擎"""
from config.settings import RISK

class RiskEngine:
    def __init__(self, portfolio, market_cfgs):
        self.portfolio    = portfolio
        self.market_cfgs = market_cfgs
        self.daily_pnl   = 0.0
        self.peak_equity = 0.0
        self.is_frozen   = False
        self.frozen_reason = ""

    def pre_check(self, order, current_price):
        """订单执行前风控检查"""
        if self.is_frozen:
            return {"pass": False, "reason": f"账户冻结: {self.frozen_reason}"}
        sym    = order["symbol"]
        action = order["action"]
        market = order.get("market", "stocks")
        risk   = RISK.get(market, {})

        # A股涨跌停检查
        if market == "stocks" and sym in self.portfolio.positions and action == "buy":
            pos = self.portfolio.positions[sym]
            pct = abs(current_price - pos["avg_cost"]) / pos["avg_cost"]
            if pct > risk.get("cn_single_limit_loss", 0.09):
                return {"pass": False, "reason": "接近涨跌停"}

        # 仓位上限
        max_pos = risk.get("max_position_pct", 0.20)
        equity  = self.portfolio.total_equity({sym: current_price})
        if action == "buy":
            val = order["shares"] * current_price
            if val / equity > max_pos:
                return {"pass": False, "reason": f"超过仓位上限 {max_pos*100:.0f}%"}
        return {"pass": True, "reason": "ok"}

    def on_market_close(self, prices):
        equity = self.portfolio.total_equity(prices)
        if equity > self.peak_equity: self.peak_equity = equity
        dd = (self.peak_equity - equity) / self.peak_equity
        if dd > RISK.get("max_drawdown_pct", 0.15):
            self.is_frozen     = True
            self.frozen_reason = f"最大回撤 {dd*100:.1f}% 超过阈值"
            return self.frozen_reason
        return None

    def unfreeze(self):
        self.is_frozen = False; self.frozen_reason = ""
        self.daily_pnl = 0.0
        self.peak_equity = self.portfolio.initial_cash
