"""
blackboard.py — 共享黑板模块

设计原则：
  - 所有专家将输出写入黑板，其他专家可读取
  - 每轮迭代开始前清空（保证无历史污染）
  - 每个写入条目带时间戳和专家标签，可追溯
"""

from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime


@dataclass
class Entry:
    """黑板条目"""
    expert   : str          # 写入专家名
    round_num: int          # 迭代轮次
    key      : str          # 条目键，如 "trend_candidates", "evaluations"
    value    : Any          # 数据内容
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%H:%M:%S"))
    note     : str = ""     # 备注说明（如"可解释性备注"）

    def __repr__(self):
        return f"[{self.expert} r{self.round_num} {self.key}@{self.timestamp}]"


class Blackboard:
    """
    共享黑板。

    用法：
      bb = Blackboard()

      # 写入
      bb.write("trend_expert", 1, "candidates", [...])

      # 按专家读取（不看自己的）
      others = bb.read_all_except(expert="evaluator", round_num=1)

      # 按key读取本轮所有
      all_evals = bb.read(key="evaluations", round_num=1)

      # 清空本轮
      bb.clear_round(1)
    """

    def __init__(self):
        self._entries: list[Entry] = []

    # ── 写入 ─────────────────────────────────

    def write(self, expert: str, round_num: int,
              key: str, value: Any, note: str = ""):
        """
        写入一条黑板记录。
        """
        entry = Entry(
            expert=expert,
            round_num=round_num,
            key=key,
            value=value,
            note=note,
        )
        self._entries.append(entry)

    # ── 读取 ─────────────────────────────────

    def read_all(self, round_num: int = None) -> list[Entry]:
        """读取某轮所有条目（默认最新轮）"""
        if round_num is None:
            round_num = self.current_round()
        return [e for e in self._entries if e.round_num == round_num]

    def read_by_expert(self, expert: str, round_num: int = None) -> list[Entry]:
        """读取某专家的条目"""
        if round_num is None:
            round_num = self.current_round()
        return [e for e in self._entries
                if e.expert == expert and e.round_num == round_num]

    def read_by_key(self, key: str, round_num: int = None) -> list[Entry]:
        """按key读取某轮所有条目"""
        if round_num is None:
            round_num = self.current_round()
        return [e for e in self._entries
                if e.key == key and e.round_num == round_num]

    def read_all_except(self, expert: str,
                        round_num: int = None) -> list[Entry]:
        """读取除某专家外的所有条目（用于评估专家不看自己的输出）"""
        if round_num is None:
            round_num = self.current_round()
        return [e for e in self._entries
                if e.expert != expert and e.round_num == round_num]

    def latest(self, expert: str, key: str) -> Optional[Any]:
        """读取某专家某key的最新值（不限轮次）"""
        matching = [
            e.value for e in reversed(self._entries)
            if e.expert == expert and e.key == key
        ]
        return matching[0] if matching else None

    def latest_by_round(self, expert: str, key: str,
                        round_num: int) -> Optional[Any]:
        """读取某轮某专家某key的值"""
        for e in reversed(self._entries):
            if e.expert == expert and e.key == key and e.round_num == round_num:
                return e.value
        return None

    def all_experts_in_round(self, round_num: int = None) -> set:
        """某轮有哪些专家写过黑板"""
        if round_num is None:
            round_num = self.current_round()
        return {e.expert for e in self._entries if e.round_num == round_num}

    # ── 管理 ─────────────────────────────────

    def current_round(self) -> int:
        """当前轮次（黑板中最新轮次号）"""
        if not self._entries:
            return 0
        return max(e.round_num for e in self._entries)

    def clear_round(self, round_num: int):
        """清空某轮所有条目（每轮开始前调用）"""
        self._entries = [e for e in self._entries if e.round_num != round_num]

    def clear_all(self):
        """完全清空黑板"""
        self._entries.clear()

    # ── 报告摘要 ─────────────────────────────

    def summary(self, round_num: int = None) -> dict:
        """生成黑板状态摘要（用于日志和报告）"""
        entries = self.read_all(round_num)
        by_expert = {}
        for e in entries:
            by_expert.setdefault(e.expert, []).append(e.key)

        return {
            "round"        : round_num or self.current_round(),
            "total_entries": len(entries),
            "experts"      : list(by_expert.keys()),
            "by_expert"    : by_expert,
        }
