"""
bull_researcher.py — 牛市研究员（看多Agent）
参考 TradingAgents Bull Researcher 架构
"""
from dataclasses import dataclass
from typing import List, Optional
import random


@dataclass
class BullCase:
    strategy_name: str
    entry_conditions: List[str]     # 看多入场条件
    upside_targets: List[str]      # 上涨目标理由
    market_tailwinds: List[str]    # 市场顺风因素
    risk_reward_ratio: float       # 风险收益比
    confidence: float               # 0~1 置信度
    summary: str


class BullResearcher:
    """专门挖掘策略上涨潜力的研究员"""

    def __init__(self, seed: int = 42):
        self.name = "BullResearcher"
        self._rng = random.Random(seed)

    def research(self, strategy_name: str, params: dict,
                 market_regime: str, ann_ret: float,
                 sharpe: float, win_rate: float,
                 regime_confidence: float = 0.8) -> BullCase:
        """
        基于策略特征生成看多案例。
        使用 llm-task 调用 LLM 做深度分析。
        """
        prompt = self._build_prompt(
            strategy_name, params, market_regime,
            ann_ret, sharpe, win_rate, regime_confidence
        )
        try:
            from experts.modules.llm_proxy import llm_analyze
            analysis = llm_analyze(
                prompt=prompt,
                task="bull_case",
                schema={
                    "type": "object",
                    "properties": {
                        "entry_conditions": {"type": "array", "items": {"type": "string"}},
                        "upside_targets": {"type": "array", "items": {"type": "string"}},
                        "market_tailwinds": {"type": "array", "items": {"type": "string"}},
                        "risk_reward_ratio": {"type": "number"},
                        "confidence": {"type": "number"},
                        "summary": {"type": "string"}
                    },
                    "required": ["entry_conditions", "upside_targets", "market_tailwinds", "risk_reward_ratio", "confidence", "summary"]
                }
            )
            return BullCase(
                strategy_name=strategy_name,
                entry_conditions=analysis.get("entry_conditions", []),
                upside_targets=analysis.get("upside_targets", []),
                market_tailwinds=analysis.get("market_tailwinds", []),
                risk_reward_ratio=analysis.get("risk_reward_ratio", 0.0),
                confidence=analysis.get("confidence", 0.5),
                summary=analysis.get("summary", ""),
            )
        except Exception as e:
            # LLM不可用时用规则回退
            return self._rule_based_bull_case(strategy_name, params, market_regime, ann_ret, sharpe, win_rate)

    def _rule_based_bull_case(self, strategy_name, params, regime, ann_ret, sharpe, win_rate) -> BullCase:
        """无LLM时的规则回退——从 strategy_name 推断类型"""
        # 从策略名推断类型（debate_manager 传入的 params 里没有 strategy_type）
        name_lower = strategy_name.lower()
        if any(k in name_lower for k in ("均线", "ma_cross", "ema", "macd", "动量", "momentum", "趋势", "adx")):
            s_type = "trend"
        elif any(k in name_lower for k in ("rsi", "布林", "bollinger", "均值", "回归", "vol_surge")):
            s_type = "mean_reversion"
        else:
            s_type = params.get("strategy_type", "trend")
        r_type = getattr(regime, "name", regime) if hasattr(regime, "name") else regime
        entry = cond_map.get(s_type, ["基本面上行支撑"])
        tails = tailwinds_map.get(r_type, ["市场环境有利"])
        rr = max(abs(ann_ret) / 20.0, 0.5) if ann_ret > 0 else 0.3
        conf = min(max(sharpe / 3.0, 0.3), 0.9) if sharpe > 0 else 0.4
        return BullCase(
            strategy_name=strategy_name,
            entry_conditions=entry,
            upside_targets=[f"年化收益目标: {ann_ret*1.5:+.1f}%", "趋势延续则加码持仓"],
            market_tailwinds=tails,
            risk_reward_ratio=round(rr, 2),
            confidence=round(conf, 2),
            summary=f"{strategy_name} 在当前市场环境下具有良好上涨潜力，顺风持仓为主策略"
        )

    @staticmethod
    def _build_prompt(strategy_name, params, regime, ann_ret, sharpe, win_rate, conf):
        return (
            f"你是量化交易的【牛市研究员】。分析以下策略的看多逻辑：\n\n"
            f"策略名: {strategy_name}\n"
            f"参数: {params}\n"
            f"市场状态: {regime}\n"
            f"年化收益: {ann_ret:+.2f}%\n"
            f"夏普比率: {sharpe:.3f}\n"
            f"胜率: {win_rate:.1f}%\n"
            f"市场置信度: {conf:.0%}\n\n"
            f"请输出该策略的看多案例，包括："
            f"最佳入场条件、上涨目标、市场顺风因素、风险收益比、置信度、总结。"
        )

    def format_bull_case(self, bc: BullCase) -> str:
        lines = [f"[{self.name}] 看多案例: {bc.strategy_name} (置信度={bc.confidence:.0%})"]
        for c in bc.entry_conditions:
            lines.append(f"  入场: {c}")
        for t in bc.upside_targets:
            lines.append(f"  目标: {t}")
        for w in bc.market_tailwinds:
            lines.append(f"  顺风: {w}")
        lines.append(f"  风险收益比: {bc.risk_reward_ratio:.2f}")
        lines.append(f"  摘要: {bc.summary}")
        return "\n".join(lines)
