"""
expert1c_network.py — 网络策略搜索专家 Expert1C
"""
import re, uuid
from dataclasses import dataclass
from typing import List


@dataclass
class ExternalStrategyRef:
    title: str; source: str; url: str
    strategy_summary: str; claimed_return: str; claimed_sharpe: str
    credibility: float; applicability: float
    tags: List[str]; weakness_note: str; source_lang: str


class NetworkSearchExpert:
    """网络搜索专家：搜索同类策略的公开回测数据"""

    def __init__(self):
        self.name = "NetworkSearchExpert"
        self._cache = {}

    def search_similar(self, strategy_type: str, market: str = "stocks") -> List[ExternalStrategyRef]:
        key = f"{strategy_type}_{market}"
        if key in self._cache:
            return self._cache[key]
        results = self._do_search(strategy_type, market)
        self._cache[key] = results
        return results

    def _do_search(self, strategy_type: str, market: str) -> List[ExternalStrategyRef]:
        """执行搜索或返回兜底数据"""
        results = []
        try:
            import __main__
            if hasattr(__main__, "batch_web_search"):
                raw = __main__.batch_web_search(queries=[
                    {"query": self._en_query(strategy_type, market), "num_results": 5},
                    {"query": self._zh_query(strategy_type, market), "num_results": 5},
                ])
                results = self._normalize(raw)
        except Exception:
            pass
        if not results:
            results = self._fallback(strategy_type, market)
        return results

    def _en_query(self, t, m):
        map_ = {"trend": "moving average crossover strategy backtest sharpe 2024",
                "mean_reversion": "RSI bollinger band mean reversion strategy backtest",
                "momentum": "momentum trading strategy backtest performance 2024"}
        return map_.get(t, f"{t} quantitative strategy backtest sharpe 2024")

    def _zh_query(self, t, m):
        map_ = {"trend": "双均线 量化策略 回测 年化 2024",
                "mean_reversion": "RSI 均值回归 布林带 量化 回测 2024",
                "momentum": "动量策略 量化 回测 收益 2024"}
        return map_.get(t, f"{t} 量化策略 回测 2024")

    def _normalize(self, raw) -> List[ExternalStrategyRef]:
        out = []
        try:
            for qr in (raw or []):
                for item in qr.get("organic_results", []):
                    out.append(self._item_to_ref(item, "en" if qr.get("query","").startswith("moving") else "zh"))
        except Exception:
            try:
                for qr in (raw or []):
                    for item in qr.get("data", []):
                        out.append(self._item_to_ref(item, "en"))
            except Exception:
                pass
        return out

    def _item_to_ref(self, item: dict, lang: str) -> ExternalStrategyRef:
        src = item.get("source",""); snippet = item.get("snippet","")
        cred = 0.9 if "quantpedia" in src.lower() else 0.8 if "ssrn" in src.lower() else 0.6 if "reddit" in src.lower() else 0.5
        return ExternalStrategyRef(
            title=item.get("title","N/A"), source=src, url=item.get("link",""),
            strategy_summary=snippet[:120], claimed_return=self._ret(snippet),
            claimed_sharpe=self._sharpe(snippet), credibility=cred,
            applicability=0.6 if "crypto" in snippet.lower() or "a股" in snippet else 0.5,
            tags=[lang], weakness_note=self._weak(snippet), source_lang=lang,
        )

    @staticmethod
    def _ret(t):
        m=re.search(r"(\d+\.?\d*)\s*%",t); return f"约{m.group(1)}%" if m else "未披露"
    @staticmethod
    def _sharpe(t):
        m=re.search(r"[Ss]harpe.?\s*(\d+\.?\d*)",t); return f"约{m.group(1)}" if m else "未披露"
    @staticmethod
    def _weak(t):
        for w in ["fail","loss","drawdown","crash","亏损","失败","陷阱"]:
            if w.lower() in t.lower(): return f"含风险词'{w}': {t[:80]}"
        return "未发现明显风险"

    def _fallback(self, t, m) -> List[ExternalStrategyRef]:
        return [ExternalStrategyRef(
            title=f"[{t}] 策略参考（网络不可用）",
            source="System (no network)", url="",
            strategy_summary=f"查询类型: {t} 市场: {m}。网络搜索功能需要有效网络连接。",
            claimed_return="未披露", claimed_sharpe="未披露",
            credibility=0.1, applicability=0.1,
            tags=[t], weakness_note="网络数据不可用", source_lang="mixed",
        )]

    def benchmark(self, reports: list) -> dict:
        refs = []
        for r in reports:
            refs.extend(self.search_similar(r.strategy_type or "trend", "stocks"))
        credible = [r for r in refs if r.credibility >= 0.6]
        if not credible:
            return {"has_benchmark": False, "summary": "无高可信网络数据，保持内部回测结果"}
        ext_returns = []
        for r in credible:
            try: ext_returns.append(float(r.claimed_return.replace("%","").replace("约","")))
            except: pass
        avg_ext = sum(ext_returns)/len(ext_returns) if ext_returns else 0.0
        avg_int = sum(r.annualized_return for r in reports)/len(reports) if reports else 0.0
        delta = avg_int - avg_ext
        advice = f"内部 vs 外部: {delta:+.1f}%。{'✅ 跑赢' if delta>0 else '⚠️ 落后'}同类基准。"
        return {
            "has_benchmark": True,
            "avg_external_return": round(avg_ext,2), "avg_internal_return": round(avg_int,2),
            "alpha_vs_benchmark": round(delta,2),
            "summary": f"内部{avg_int:.1f}% vs 外部{avg_ext:.1f}%，delta={delta:+.1f}%",
            "advice": advice,
            "refs_count": len(refs), "high_credible_count": len(credible),
        }
