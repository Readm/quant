"""
expert2_evaluator.py — 评估专家（纯Python版）
"""

from dataclasses import dataclass
from .expert1_generator import BacktestReport


@dataclass
class EvaluationCriteria:
    min_sharpe:        float = 0.5
    max_drawdown_pct:  float = 25.0
    min_win_rate:      float = 35.0
    min_profit_factor: float = 1.2
    min_total_trades:  int   = 3
    min_calmar:        float = 0.3


@dataclass
class EvaluatedReport:
    original: BacktestReport
    sharpe_score:    float = 0.0
    drawdown_score:  float = 0.0
    winrate_score:   float = 0.0
    profit_score:    float = 0.0
    stability_score: float = 0.0
    composite_score: float = 0.0
    decision: str = "REJECT"
    decision_reason: str = ""
    feedback_for_expert1: str = ""
    rank: int = 0


def score_sharpe(sr: float) -> float:
    return min(100.0, max(0.0, 50 + (sr - 0.5) * 20))

def score_drawdown(dd: float) -> float:
    return max(0.0, 100 - dd * 4)

def score_winrate(wr: float) -> float:
    return max(0.0, 60 + (wr - 50) * 2)

def score_profit_factor(pf: float) -> float:
    if pf >= 3.0: return 100.0
    if pf >= 1.0: return 30 + (pf - 1.0) / 2.0 * 70
    return max(0.0, 30 - (1.0 - pf) * 30)

def score_stability(calmar: float) -> float:
    if calmar >= 1.0: return 100.0
    if calmar >= 0:   return calmar / 1.0 * 100
    return max(0.0, 50 + calmar * 25)

CRITERIA = EvaluationCriteria()


def evaluate(report: BacktestReport) -> EvaluatedReport:
    ev = EvaluatedReport(original=report)
    r  = report

    ev.sharpe_score    = score_sharpe(r.sharpe_ratio)
    ev.drawdown_score  = score_drawdown(r.max_drawdown_pct)
    ev.winrate_score   = score_winrate(r.win_rate)
    ev.profit_score    = score_profit_factor(r.profit_factor)
    ev.stability_score = score_stability(r.calmar_ratio)

    ev.composite_score = round(
        ev.sharpe_score    * 0.35 +
        ev.drawdown_score  * 0.25 +
        ev.winrate_score   * 0.15 +
        ev.profit_score    * 0.15 +
        ev.stability_score * 0.10, 2)

    reasons = []
    reject  = False
    c = CRITERIA

    if r.total_trades < c.min_total_trades:
        reasons.append(f"交易不足({r.total_trades}<{c.min_total_trades})")
        reject = True
    if r.sharpe_ratio < c.min_sharpe:
        reasons.append(f"夏普<{c.min_sharpe}({r.sharpe_ratio:.3f})")
        reject = True
    if r.max_drawdown_pct > c.max_drawdown_pct:
        reasons.append(f"回撤过大({r.max_drawdown_pct:.1f}%>{c.max_drawdown_pct}%)")
        reject = True
    if r.win_rate < c.min_win_rate:
        reasons.append(f"胜率偏低({r.win_rate:.1f}%<{c.min_win_rate}%)")
        reject = True
    if r.profit_factor < c.min_profit_factor:
        reasons.append(f"盈亏比不足({r.profit_factor:.2f}<{c.min_profit_factor})")
        reject = True

    ev.decision_reason = "；".join(reasons) if reasons else "各项达标"
    ev.decision = "REJECT" if reject else ("ACCEPT" if ev.composite_score >= 60 else "CONDITIONAL")
    ev.feedback_for_expert1 = _feedback(ev)
    return ev


def _feedback(ev: EvaluatedReport) -> str:
    r = ev.original
    tips = []
    if r.sharpe_ratio < 0.5:
        tips.append("收紧止损减少无效交易")
    if r.max_drawdown_pct > 20:
        tips.append("降低单笔仓位")
    if r.win_rate < 40:
        tips.append("缩短持仓周期或提前止盈")
    if r.profit_factor < 1.3:
        tips.append("优化出场逻辑减少赢转亏")
    if r.calmar_ratio < 0.5:
        tips.append("增加趋势确认过滤假信号")
    if r.total_trades < 10:
        tips.append("放宽入场条件或缩短均线周期")
    if not tips:
        tips.append("指标良好，可适当扩大仓位")
    return "；".join(tips)


def evaluate_batch(reports: list) -> list:
    evaled = [evaluate(r) for r in reports]
    evaled.sort(key=lambda x: x.composite_score, reverse=True)
    for i, e in enumerate(evaled):
        e.rank = i + 1
    return evaled


def run_evaluation(iter_result: dict) -> dict:
    reports = iter_result.get("reports", [])
    evaled  = evaluate_batch(reports)
    evaled.sort(key=lambda x: x.composite_score, reverse=True)

    accepted   = [e for e in evaled if e.decision == "ACCEPT"]
    conditional= [e for e in evaled if e.decision == "CONDITIONAL"]
    rejected   = [e for e in evaled if e.decision == "REJECT"]

    top3 = evaled[:3]
    rejected_list = evaled[3:]

    def _avg(field):
        src = accepted + conditional
        vals = [e.original.__dict__[field] for e in src]
        return round(sum(vals)/len(vals), 3) if vals else 0.0

    summary = {
        "total"         : len(reports),
        "accepted_count": len(accepted),
        "cond_count"    : len(conditional),
        "rejected_count": len(rejected),
        "avg_sharpe"    : _avg("sharpe_ratio"),
        "avg_return"    : _avg("total_return"),
        "avg_drawdown"  : _avg("max_drawdown_pct"),
        "avg_winrate"   : _avg("win_rate"),
    }

    feedback = []
    for e in accepted + conditional:
        r = e.original
        name = r.strategy_name
        if "均线" in name: fb_type = "均线"
        elif "RSI" in name: fb_type = "RSI"
        elif "MACD" in name: fb_type = "MACD"
        elif "波动" in name: fb_type = "波动率"
        elif "布林" in name: fb_type = "布林"
        else: fb_type = name
        feedback.append({
            "strategy_id"  : r.strategy_id,
            "strategy_name": r.strategy_name,
            "feedback"     : e.feedback_for_expert1,
            "feedback_type": fb_type,
            "composite_score": e.composite_score,
        })

    return {
        "round"         : 1,
        "summary"       : summary,
        "top3"          : top3,
        "rejected_list" : rejected_list,
        "feedback"      : feedback,
        "accepted"      : accepted,
        "conditional"   : conditional,
        "rejected"      : rejected,
    }


def print_evaluation_report(er: dict):
    sm = er["summary"]
    print("\n" + "=" * 65)
    print(f"  第 {er['round']} 轮评估报告")
    print("=" * 65)
    print(f"\n📊 统计：共 {sm['total']} 个候选 | "
          f"✅ 纳入 {sm['accepted_count']} | "
          f"⚠️ 待观察 {sm['cond_count']} | ❌ 淘汰 {sm['rejected_count']}")

    top3 = er.get("top3", [])
    if top3:
        print(f"\n🏆 Top 3 策略：")
        for ev in top3:
            r = ev.original
            print(f"\n  #{ev.rank} [{r.strategy_name}]（{','.join(r.tags)}）")
            print(f"     综合分: {ev.composite_score}/100 | 收益: {r.total_return}% | "
                  f"夏普: {r.sharpe_ratio} | 回撤: {r.max_drawdown_pct}%")
            print(f"     胜率: {r.win_rate}% | 盈亏比: {r.profit_factor} | 卡曼: {r.calmar_ratio}")
            print(f"     参数: {r.params}")
            print(f"     ✅ {ev.decision} — {ev.decision_reason}")

    rej = er.get("rejected_list", [])
    if rej:
        print(f"\n❌ 淘汰（{len(rej)} 个）：")
        for ev in rej:
            r = ev.original
            print(f"  [{r.strategy_name}] {ev.decision_reason} | 分: {ev.composite_score}")

    fb = er.get("feedback", [])
    if fb:
        print(f"\n📝 下一轮优化方向：")
        for f in fb:
            print(f"  • {f['strategy_name']}：{f['feedback']}")
    print("\n" + "=" * 65)
