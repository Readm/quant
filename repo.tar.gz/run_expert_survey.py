#!/usr/bin/env python3
"""
run_expert_survey.py — 运行 Expert3（公开策略调查）+ Expert4（数据集调查）
输出：
  results/expert3_survey_YYYYMMDD.json
  results/expert4_dataset_YYYYMMDD.json
  屏幕打印两份完整报告

用法：
  python3 quant/run_expert_survey.py
"""
import sys, json
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

RESULTS = Path(__file__).parent / "results"
RESULTS.mkdir(parents=True, exist_ok=True)
STAMP = datetime.now().strftime("%Y%m%d_%H%M")


def save(data, name):
    path = RESULTS / f"{name}_{STAMP}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"💾 已保存: {path}")
    return path


# ── Expert3: 公开策略调查 ─────────────────────────────────
print("\n" + "▓" * 60)
print("  Expert3 · 公开策略收集专家")
print("▓" * 60)

from experts.specialists.expert3_surveyor import StrategySurveyor

survey = StrategySurveyor()
survey_report = survey.generate_report()
survey_report.print()

# 保存 JSON
survey_data = {
    "generated_at": survey_report.generated_at,
    "total_strategies": survey_report.total_strategies,
    "by_family": survey_report.by_family,
    "top_picks": survey_report.top_picks,
    "recommendations": survey_report.recommendations,
    "gaps": survey_report.gaps,
    "user_action_required": survey_report.user_action_required,
}
save(survey_data, "expert3_survey")


# ── Expert4: 数据集调查 ─────────────────────────────────
print("\n" + "▓" * 60)
print("  Expert4 · 数据集收集专家")
print("▓" * 60)

from experts.specialists.expert4_dataset_specialist import DatasetSpecialist

ds = DatasetSpecialist()
ds_report = ds.generate_report()
ds_report.print()

# 保存 JSON
ds_data = {
    "generated_at": ds_report.generated_at,
    "total_sources": ds_report.total_sources,
    "working_sources": ds_report.working_sources,
    "by_category": ds_report.by_category,
    "quality_matrix": [
        {"rank": q["rank"], "source": q["source"]}
        for q in ds_report.quality_matrix
    ],
    "integration_roadmap": ds_report.integration_roadmap,
    "immediate_action": ds_report.immediate_action,
    "user_commitments": ds_report.user_commitments,
    "gaps": ds_report.gaps,
    "summary": ds_report.summary,
}
save(ds_data, "expert4_dataset")


# ── 汇总：用户需要做什么 ────────────────────────────────
print("\n" + "▓" * 60)
print("  📋 用户待办清单 — 综合两份报告")
print("▓" * 60)

print("""
  ┌─────────────────────────────────────────────────────┐
  │  优先级   操作                          预计时间    │
  ├─────────────────────────────────────────────────────┤
  │  P0       注册 TuShare Pro Token       10分钟      │
  │  P1       Binance 分钟级数据接入        1小时       │
  │  P2       补充港股数据覆盖              30分钟      │
  │  P3       简历PDF内容粘贴（可选）       5分钟       │
  └─────────────────────────────────────────────────────┘
""")

print("  📌 TuShare Token 获取步骤：")
print("    1. 访问 https://tushare.pro/register?reg=529")
print("    2. 注册账号（支持微信/手机号）")
print("    3. 登录后：个人中心 → API Token")
print("    4. 复制 Token，告诉我，我直接写入配置")

print("\n  ✅ 两份报告已生成：")
print(f"    · 策略报告: results/expert3_survey_{STAMP}.json")
print(f"    · 数据报告: results/expert4_dataset_{STAMP}.json")
print("▓" * 60)
