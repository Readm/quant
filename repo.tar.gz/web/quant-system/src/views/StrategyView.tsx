import { useState } from 'react'
import { ListOrdered, Zap } from 'lucide-react'

const familyColors: Record<string,string> = {
  "趋势":"#6366f1","均值回归":"#22d3ee","波幅":"#4ade80",
  "量价":"#fbbf24","时序":"#f87171","Ichimoku":"#a78bfa",
  "KST/TRIX":"#f97316","缠论":"#ec4899","复合信号":"#14b8a6",
}

const allFactors = [
  // ── 趋势类（F00-F05）──────────────────────────────
  { id:"F00",name:"MA金叉(5,20)",     family:"趋势" },
  { id:"F01",name:"MA金叉(10,60)",    family:"趋势" },
  { id:"F02",name:"MACD(12,26,9)",   family:"趋势" },
  { id:"F03",name:"3月动量正",        family:"趋势" },
  { id:"F04",name:"ATR突破(20日)",    family:"趋势" },
  { id:"F05",name:"价格>20日均线",    family:"趋势" },
  // ── 均值回归类（F06-F11）────────────────────────────
  { id:"F06",name:"RSI超卖25",       family:"均值回归" },
  { id:"F07",name:"RSI超卖30",       family:"均值回归" },
  { id:"F08",name:"RSI<40买入",      family:"均值回归" },
  { id:"F09",name:"布林下轨买入",     family:"均值回归" },
  { id:"F10",name:"布林上轨卖出",     family:"均值回归" },
  { id:"F11",name:"KDJ超卖反弹",      family:"均值回归" },
  // ── 波幅类（F12-F14）────────────────────────────────
  { id:"F12",name:"ATR放大确认",     family:"波幅" },
  { id:"F13",name:"ATR收缩预警",     family:"波幅" },
  { id:"F14",name:"波幅收缩爆发",    family:"波幅" },
  // ── 时序类（F15-F16）────────────────────────────────
  { id:"F15",name:"ROC定价过高",      family:"时序" },
  { id:"F16",name:"连涨3日",         family:"时序" },
  // ── Ichimoku 云图（F17-F19）─────────────────────────
  { id:"F17",name:"Ichimoku云图",    family:"Ichimoku" },
  { id:"F18",name:"Ichimoku金叉",    family:"Ichimoku" },
  { id:"F19",name:"Parabolic SAR",   family:"Ichimoku" },
  // ── 多周期趋势（F20-F23）────────────────────────────
  { id:"F20",name:"KST多周期动量",   family:"KST/TRIX" },
  { id:"F21",name:"TRIX三重指数",     family:"KST/TRIX" },
  { id:"F22",name:"Donchian突破",    family:"KST/TRIX" },
  { id:"F23",name:"Aroon交叉",       family:"KST/TRIX" },
  { id:"F24",name:"PPO信号",         family:"KST/TRIX" },
  { id:"F25",name:"Supertrend",      family:"KST/TRIX" },
  // ── 量价类（F26-F32）────────────────────────────────
  { id:"F26",name:"MFI资金流",       family:"量价" },
  { id:"F27",name:"RVI相对活力",     family:"量价" },
  { id:"F28",name:"多周期动量矩阵",  family:"量价" },
  { id:"F29",name:"ROC多周期一致",   family:"量价" },
  { id:"F30",name:"OBOS综合超买超卖",family:"量价" },
  { id:"F31",name:"KDJ波动波形",     family:"量价" },
  { id:"F32",name:"VPT量价趋势",     family:"量价" },
  // ── 成交量类（F33-F38）───────────────────────────────
  { id:"F33",name:"Force Index力",   family:"量价" },
  { id:"F34",name:"Elder Ray透视",   family:"量价" },
  { id:"F35",name:"Elder Ray信号",   family:"量价" },
  { id:"F36",name:"Chaikin振荡器",   family:"量价" },
  { id:"F37",name:"A/D累积派发",     family:"量价" },
  { id:"F38",name:"A/D背离信号",     family:"量价" },
  // ── 波幅突破类（F39-F44）─────────────────────────────
  { id:"F39",name:"Ultra-Band突破",  family:"波幅" },
  { id:"F40",name:"Signal Horizon",  family:"波幅" },
  { id:"F41",name:"Mass Index梅斯",  family:"波幅" },
  { id:"F42",name:"Ergodic遍历摆动",family:"波幅" },
  { id:"F43",name:"CCI顺势指标",     family:"波幅" },
  { id:"F44",name:"Williams %R",    family:"波幅" },
  // ── 成交量工具（F45）────────────────────────────────
  { id:"F45",name:"成交量比率VR",    family:"量价" },
  // ── 缠论类（F46-F47）────────────────────────────────
  { id:"F46",name:"缠论笔",          family:"缠论" },
  { id:"F47",name:"缠论套",          family:"缠论" },
  // ── 复合背离信号（F48-F55）───────────────────────────
  { id:"F48",name:"MACD背离",       family:"复合信号" },
  { id:"F49",name:"RSI背离",        family:"复合信号" },
  { id:"F50",name:"KD随机背离",     family:"复合信号" },
  { id:"F51",name:"趋势线突破",      family:"复合信号" },
  { id:"F52",name:"Pivot反转",       family:"复合信号" },
  { id:"F53",name:"波浪脉冲",        family:"复合信号" },
  { id:"F54",name:"动量背离",       family:"复合信号" },
  { id:"F55",name:"ADX趋势过滤",    family:"复合信号" },
]

const strategies = [
  {
    name:"AND.F05+F14",
    factors:["F05","F14"],
    mode:"AND",
    ann:17.8, rel:18.7, sharpe:0.061, dd:9.8, trades:2, winrate:50, grade:"B",
    families:["趋势","波幅"],
    desc:"价格突破20日均线 AND 波幅收缩至低位 → 趋势确认+波幅临界，高概率向上突破",
    pbo_score:0.78, pbo_label:"🟡可接受",
  },
  {
    name:"AND.F02+F11",
    factors:["F02","F11"],
    mode:"AND",
    ann:16.1, rel:17.0, sharpe:0.055, dd:16.1, trades:13, winrate:62, grade:"B",
    families:["趋势","均值回归"],
    desc:"MACD金叉 AND KDJ超卖 → 趋势顺势+超卖反弹双确认",
    pbo_score:0.65, pbo_label:"🟡可接受",
  },
  {
    name:"W3.F00+F03+F04",
    factors:["F00","F03","F04"],
    mode:"WEIGHT",
    ann:18.5, rel:19.4, sharpe:0.059, dd:16.3, trades:2, winrate:33, grade:"C",
    families:["趋势"],
    desc:"三趋势因子等权组合：MA金叉+动量+ATR突破同时满足 → 最强信号",
    pbo_score:0.42, pbo_label:"🟠轻度过拟合",
  },
  {
    name:"布林带(20,2.5)",
    factors:["F09","F10"],
    mode:"单因子",
    ann:9.4, rel:10.3, sharpe:0.029, dd:14.7, trades:7, winrate:71, grade:"C",
    families:["均值回归"],
    desc:"布林带单因子，下轨买入上轨卖出，震荡市有效",
    pbo_score:0.81, pbo_label:"🟢稳健",
  },
  {
    name:"RSI超卖25",
    factors:["F06"],
    mode:"单因子",
    ann:-14.4, rel:-13.5, sharpe:-0.047, dd:34.4, trades:5, winrate:40, grade:"D",
    families:["均值回归"],
    desc:"RSI单因子，熊市有效但趋势市失效，需配合趋势过滤器",
    pbo_score:0.35, pbo_label:"🔴中度过拟合",
  },
  {
    name:"Ichimoku+KST",
    factors:["F17","F18","F20"],
    mode:"AND",
    ann:22.1, rel:23.0, sharpe:0.072, dd:11.2, trades:8, winrate:58, grade:"A",
    families:["Ichimoku","KST/TRIX"],
    desc:"Ichimoku云图确认 + KST多周期动量 → 双重趋势共振信号",
    pbo_score:0.71, pbo_label:"🟡可接受",
  },
  {
    name:"MACD背离+F04",
    factors:["F48","F04"],
    mode:"AND",
    ann:19.3, rel:20.2, sharpe:0.064, dd:8.9, trades:6, winrate:67, grade:"A",
    families:["复合信号","趋势"],
    desc:"MACD底背离 + ATR趋势确认 → 反转+趋势双确认，胜率高",
    pbo_score:0.68, pbo_label:"🟡可接受",
  },
  {
    name:"Aroon+Donchian",
    factors:["F23","F22"],
    mode:"AND",
    ann:15.7, rel:16.6, sharpe:0.051, dd:13.5, trades:4, winrate:55, grade:"B",
    families:["KST/TRIX"],
    desc:"Aroon趋势转换确认 + Donchian区间突破 → 趋势启动早期信号",
    pbo_score:0.74, pbo_label:"🟡可接受",
  },
  {
    name:"ForceIndex+ ElderRay",
    factors:["F33","F34"],
    mode:"WEIGHT",
    ann:13.2, rel:14.1, sharpe:0.044, dd:10.8, trades:9, winrate:61, grade:"B",
    families:["量价"],
    desc:"Force Index力度 + Elder Ray透视 → 量价同步确认信号",
    pbo_score:0.77, pbo_label:"🟡可接受",
  },
  {
    name:"缠论笔+Pivot",
    factors:["F46","F52"],
    mode:"AND",
    ann:11.8, rel:12.7, sharpe:0.038, dd:9.2, trades:3, winrate:70, grade:"B",
    families:["缠论","复合信号"],
    desc:"缠论笔方向 + Pivot支撑阻力 → 中式技术分析系统",
    pbo_score:0.82, pbo_label:"🟢稳健",
  },
]

function GradeBadge({ grade }: { grade: string }) {
  const cfg = grade === "A" ? "bg-green-500/20 text-green-400" : grade === "B" ? "bg-blue-500/20 text-blue-400" : grade === "C" ? "bg-yellow-500/20 text-yellow-400" : "bg-red-500/20 text-red-400"
  return <span className={"px-2 py-0.5 rounded text-xs font-bold " + cfg}>{grade}</span>
}

export default function StrategyView() {
  const [sel, setSel] = useState<any>(null)
  const [family, setFamily] = useState<string>("全部")

  const families = ["全部", "趋势", "均值回归", "波幅", "时序", "Ichimoku", "KST/TRIX", "量价", "缠论", "复合信号"]
  const pboLabel = (s: any) => s.pbo_label || s.weight?.pbo_label || '—'
  const pboScore = (s: any) => s.pbo_score ?? s.weight?.pbo_score ?? null

  const filtered = family === "全部"
    ? strategies
    : strategies.filter((s: any) => s.families.includes(family))

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <ListOrdered size={24} className="text-yellow-400" />
        <div>
          <h2 className="text-xl font-bold text-white">因子策略库</h2>
          <p className="text-slate-400 text-sm">58 因子 · 10 精选策略 · PBO 稳健性评级</p>
        </div>
      </div>

      {/* 因子类别筛选 */}
      <div className="flex gap-2 flex-wrap">
        {families.map(f => (
          <button key={f} onClick={() => setFamily(f)}
            className={"px-3 py-1.5 rounded-full text-xs font-medium border transition-all " +
              (family === f
                ? "bg-indigo-600 text-white border-indigo-500"
                : "bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500")}>
            {f}
          </button>
        ))}
      </div>

      {/* 因子图例 */}
      <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700">
        <div className="text-xs text-slate-500 mb-2 font-medium">全部因子（F00-F55）</div>
        <div className="flex flex-wrap gap-1.5">
          {allFactors.map(f => (
            <span key={f.id}
              className="px-2 py-1 rounded text-xs"
              style={{
                backgroundColor: (familyColors[f.family]||"#94a3b8") + "22",
                color: familyColors[f.family]||"#94a3b8",
                border: `1px solid ${familyColors[f.family]||"#94a3b8"}33`,
              }}>
              <span className="font-mono opacity-60">{f.id}</span> {f.name}
            </span>
          ))}
        </div>
      </div>

      {/* 策略表格 */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700 bg-slate-900/50">
                {["策略名","因子","模式","年化","超额","夏普","PBO","回撤","交易","胜率","等级"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs text-slate-500 font-medium whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((s:any, i:number) => (
                <tr key={i} onClick={() => setSel(sel?.name === s.name ? null : s)}
                  className={"border-b border-slate-700/50 cursor-pointer transition-colors " +
                    (sel?.name === s.name ? "bg-indigo-900/20" : "hover:bg-slate-700/30")}>
                  <td className="px-4 py-3 font-medium text-white whitespace-nowrap">{s.name}</td>
                  <td className="px-4 py-3 text-xs text-slate-400">{s.factors.join("+")}</td>
                  <td className="px-4 py-3"><span className="px-1.5 py-0.5 bg-slate-700 rounded text-xs text-slate-300">{s.mode}</span></td>
                  <td className="px-4 py-3 whitespace-nowrap" style={{ color: s.ann > 0 ? "#4ade80" : "#f87171" }}>
                    {s.ann > 0 ? "+" : ""}{s.ann}%
                  </td>
                  <td className="px-4 py-3 text-green-400 whitespace-nowrap">{s.rel > 0 ? "+" : ""}{s.rel}%</td>
                  <td className="px-4 py-3 text-slate-300">{s.sharpe > 0 ? "+" : ""}{s.sharpe}</td>
                  <td className="px-4 py-3 text-center">
                    {(() => {
                      const label = pboLabel(s)
                      const score = pboScore(s)
                      return label && label !== '—' ? (
                        <span className="text-xs">
                          <span className="font-medium">{label}</span>
                          <span className="text-slate-500 ml-0.5">({(score ?? 0).toFixed(2)})</span>
                        </span>
                      ) : <span className="text-slate-600 text-xs">—</span>
                    })()}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap" style={{ color: s.dd < 10 ? "#4ade80" : "#f87171" }}>
                    {s.dd}%
                  </td>
                  <td className="px-4 py-3 text-slate-400">{s.trades}次</td>
                  <td className="px-4 py-3 text-slate-300">{s.winrate}%</td>
                  <td className="px-4 py-3"><GradeBadge grade={s.grade} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* PBO 图例 */}
      <div className="flex flex-wrap gap-4 text-xs text-slate-400 border border-slate-700 rounded-lg p-3 bg-slate-800/40">
        <span className="flex items-center gap-1"><span className="text-green-400">🟢</span>PBO≥0.80 稳健</span>
        <span className="flex items-center gap-1"><span className="text-yellow-400">🟡</span>PBO≥0.60 可接受</span>
        <span className="flex items-center gap-1"><span className="text-orange-400">🟠</span>PBO≥0.40 轻度过拟合</span>
        <span className="flex items-center gap-1"><span className="text-red-400">🔴</span>PBO≥0.20 中度过拟合</span>
        <span className="flex items-center gap-1"><span className="text-slate-500">⚫</span>PBO&lt;0.20 严重过拟合</span>
      </div>

      {/* 策略详情 */}
      {sel && (
        <div className="bg-slate-800 rounded-xl p-6 border-2 border-indigo-500/40">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-bold text-lg">{sel.name}</h3>
            <div className="flex gap-2">
              <GradeBadge grade={sel.grade} />
              <span className="text-xs text-slate-500 bg-slate-900 px-2 py-1 rounded">{sel.pbo_label} PBO</span>
            </div>
          </div>
          <p className="text-slate-300 text-sm mb-4">{sel.desc}</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
            {[
              { label:"年化收益", val:(sel.ann>0?"+":"")+sel.ann+"%", c:sel.ann>0?"#4ade80":"#f87171" },
              { label:"超额基准", val:(sel.rel>0?"+":"")+sel.rel+"%", c:"#4ade80" },
              { label:"夏普比率", val:(sel.sharpe>0?"+":"")+sel.sharpe, c:"#22d3ee" },
              { label:"PBO稳健", val:(sel.pbo_score??0).toFixed(3), c: sel.pbo_score>=0.6?"#4ade80":"#f87171" },
              { label:"最大回撤", val:sel.dd+"%", c:sel.dd<10?"#4ade80":"#f87171" },
            ].map((x:any) => (
              <div key={x.label} className="bg-slate-900 rounded-lg p-3 text-center">
                <div className="text-xs text-slate-500 mb-1">{x.label}</div>
                <div className="text-lg font-bold" style={{ color: x.c }}>{x.val}</div>
              </div>
            ))}
          </div>
          <div className="mb-3">
            <div className="text-xs text-slate-500 mb-2">组成因子</div>
            <div className="flex gap-2 flex-wrap">
              {sel.factors.map((fid:any) => {
                const f = allFactors.find((a:any) => a.id === fid)
                return f ? (
                  <span key={fid} className="px-2 py-1 rounded text-xs"
                    style={{
                      backgroundColor: (familyColors[f.family]||"#94a3b8")+"33",
                      color: familyColors[f.family]||"#94a3b8",
                      border: `1px solid ${familyColors[f.family]||"#94a3b8"}44`,
                    }}>
                    <span className="font-mono opacity-60">{fid}</span> {f.name}
                  </span>
                ) : null
              })}
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {sel.families.map((fam:any) => (
              <span key={fam} className="px-2 py-1 rounded text-xs"
                style={{ backgroundColor: (familyColors[fam]||"#94a3b8")+"22", color: familyColors[fam]||"#94a3b8" }}>
                {fam}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* 推荐策略 */}
      <div className="bg-gradient-to-r from-indigo-900/40 to-purple-900/40 rounded-xl p-6 border border-indigo-500/30">
        <div className="flex items-center gap-3 mb-3">
          <Zap size={20} className="text-indigo-400" />
          <span className="text-indigo-300 font-semibold">综合推荐</span>
          <span className="px-2 py-0.5 bg-indigo-500/30 rounded-full text-xs text-indigo-300 border border-indigo-400/30">A级 · 🟢稳健</span>
        </div>
        <div className="text-white font-bold text-lg mb-1">MACD背离+F04（MACD底背离 × ATR趋势确认）</div>
        <div className="text-slate-300 text-sm mb-3">年化 +19.3% · 超额 +20.2% · 回撤 8.9% · 夏普 0.064 · PBO=0.68（🟡可接受）</div>
        <div className="text-xs text-slate-500">适用: 趋势反转初期 · 复合信号+趋势双重确认</div>
      </div>
    </div>
  )
}
